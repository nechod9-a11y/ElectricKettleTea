package com.illia.electrickettle.event;

import com.illia.electrickettle.ElectricKettleTea;
import com.illia.electrickettle.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ElectricKettleTea.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class CreativeTabEvents {
    @SubscribeEvent
    public static void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.KETTLE);
            event.accept(ModItems.EMPTY_CUP);
            event.accept(ModItems.BLACK_TEA_BAG);
            event.accept(ModItems.GREEN_TEA_BAG);
            event.accept(ModItems.BLACK_TEA);
            event.accept(ModItems.GREEN_TEA);
        }
    }
}
