package com.illia.electrickettle.registry;

import com.illia.electrickettle.ElectricKettleTea;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ElectricKettleTea.MOD_ID);
    public static final RegistryObject<Item> KETTLE = ITEMS.register("electric_kettle", () -> new BlockItem(ModBlocks.ELECTRIC_KETTLE.get(), new Item.Properties()));
    public static final RegistryObject<Item> EMPTY_CUP = ITEMS.register("empty_cup", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BLACK_TEA_BAG = ITEMS.register("black_tea_bag", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> GREEN_TEA_BAG = ITEMS.register("green_tea_bag", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BLACK_TEA = ITEMS.register("black_tea", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> GREEN_TEA = ITEMS.register("green_tea", () -> new Item(new Item.Properties().stacksTo(16)));
}
