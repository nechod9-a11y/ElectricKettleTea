package com.illia.electrickettle.registry;

import com.illia.electrickettle.ElectricKettleTea;
import com.illia.electrickettle.block.entity.ElectricKettleBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ElectricKettleTea.MOD_ID);
    public static final RegistryObject<BlockEntityType<ElectricKettleBlockEntity>> KETTLE = BLOCK_ENTITIES.register("electric_kettle", () -> BlockEntityType.Builder.of(ElectricKettleBlockEntity::new, ModBlocks.ELECTRIC_KETTLE.get()).build(null));
}
