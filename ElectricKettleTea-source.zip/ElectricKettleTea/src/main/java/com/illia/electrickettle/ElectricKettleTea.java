package com.illia.electrickettle;

import com.illia.electrickettle.registry.ModBlocks;
import com.illia.electrickettle.registry.ModBlockEntities;
import com.illia.electrickettle.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ElectricKettleTea.MOD_ID)
public class ElectricKettleTea {
    public static final String MOD_ID = "electrickettle";
    public ElectricKettleTea() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
    }
}
