package com.illia.electrickettle.block;

import com.illia.electrickettle.block.entity.ElectricKettleBlockEntity;
import com.illia.electrickettle.registry.ModBlockEntities;
import com.illia.electrickettle.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

public class ElectricKettleBlock extends BaseEntityBlock {
    public ElectricKettleBlock(Properties properties) { super(properties); }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Nullable @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new ElectricKettleBlockEntity(pos, state); }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof ElectricKettleBlockEntity kettle)) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;

        if (held.is(Items.WATER_BUCKET)) {
            if (kettle.fillWater()) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                if (!player.getAbilities().instabuild && held.isEmpty()) player.setItemInHand(hand, new ItemStack(Items.BUCKET));
                else if (!player.getAbilities().instabuild) player.getInventory().add(new ItemStack(Items.BUCKET));
                player.displayClientMessage(Component.literal("Water added to the kettle."), true);
            } else player.displayClientMessage(Component.literal("The kettle already has water."), true);
            return InteractionResult.CONSUME;
        }
        if (held.is(Items.COAL) || held.is(Items.CHARCOAL)) {
            if (kettle.addFuel()) { if (!player.getAbilities().instabuild) held.shrink(1); player.displayClientMessage(Component.literal("The kettle is heating!"), true); }
            else player.displayClientMessage(Component.literal("Add water first, or the kettle is already heating."), true);
            return InteractionResult.CONSUME;
        }
        if (held.is(ModItems.BLACK_TEA_BAG.get()) || held.is(ModItems.GREEN_TEA_BAG.get())) {
            boolean green = held.is(ModItems.GREEN_TEA_BAG.get());
            if (kettle.addTea(green)) { if (!player.getAbilities().instabuild) held.shrink(1); player.displayClientMessage(Component.literal("Tea is steeping. Use an empty cup to collect it."), true); }
            else player.displayClientMessage(Component.literal("The water must be boiled first, and the kettle must not already contain tea."), true);
            return InteractionResult.CONSUME;
        }
        if (held.is(ModItems.EMPTY_CUP.get())) {
            ItemStack tea = kettle.collectTea();
            if (!tea.isEmpty()) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                if (!player.getInventory().add(tea)) player.drop(tea, false);
                player.displayClientMessage(Component.literal("Enjoy your tea!"), true);
            } else player.displayClientMessage(Component.literal("There is no brewed tea ready."), true);
            return InteractionResult.CONSUME;
        }
        player.displayClientMessage(Component.literal(kettle.getStatus()), true);
        return InteractionResult.CONSUME;
    }

    @Override public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (state.getBlock() != newState.getBlock()) super.onRemove(state, level, pos, newState, moving);
    }

    @Override public <T extends BlockEntity> net.minecraft.world.level.block.entity.BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return type == ModBlockEntities.KETTLE.get() ? (lvl, pos, st, be) -> ElectricKettleBlockEntity.tick(lvl, pos, st, (ElectricKettleBlockEntity) be) : null;
    }
}
