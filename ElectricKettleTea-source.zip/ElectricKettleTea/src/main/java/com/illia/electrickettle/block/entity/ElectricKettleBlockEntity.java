package com.illia.electrickettle.block.entity;

import com.illia.electrickettle.registry.ModBlockEntities;
import com.illia.electrickettle.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class ElectricKettleBlockEntity extends BlockEntity {
    private boolean hasWater = false;
    private boolean boiled = false;
    private int fuelTicks = 0;
    private int heatProgress = 0;
    // 0 = no tea, 1 = black, 2 = green
    private int teaType = 0;

    public ElectricKettleBlockEntity(BlockPos pos, BlockState state) { super(ModBlockEntities.KETTLE.get(), pos, state); }

    public boolean fillWater() {
        if (hasWater) return false;
        hasWater = true; boiled = false; heatProgress = 0; teaType = 0; setChanged(); return true;
    }
    public boolean addFuel() {
        if (!hasWater || boiled || fuelTicks > 0) return false;
        fuelTicks = 200; setChanged(); return true;
    }
    public boolean addTea(boolean green) {
        if (!boiled || teaType != 0) return false;
        teaType = green ? 2 : 1; setChanged(); return true;
    }
    public ItemStack collectTea() {
        if (!boiled || teaType == 0) return ItemStack.EMPTY;
        ItemStack result = new ItemStack(teaType == 1 ? ModItems.BLACK_TEA.get() : ModItems.GREEN_TEA.get());
        hasWater = false; boiled = false; heatProgress = 0; fuelTicks = 0; teaType = 0; setChanged(); return result;
    }
    public String getStatus() {
        if (!hasWater) return "Kettle is empty. Add a water bucket.";
        if (boiled && teaType == 0) return "Water has boiled! Add a tea bag.";
        if (boiled) return "Tea is ready! Use an empty cup to collect it.";
        if (fuelTicks > 0) return "Heating water: " + Math.min(100, heatProgress) + "%";
        return "Water is cold. Add coal or charcoal to heat it.";
    }

    public static void tick(Level level, BlockPos pos, BlockState state, ElectricKettleBlockEntity kettle) {
        if (level.isClientSide || !kettle.hasWater || kettle.boiled || kettle.fuelTicks <= 0) return;
        kettle.fuelTicks--;
        kettle.heatProgress++;
        if (kettle.heatProgress >= 100) { kettle.boiled = true; kettle.fuelTicks = 0; }
        if (kettle.level != null && (kettle.heatProgress % 10 == 0 || kettle.boiled)) kettle.setChanged();
    }

    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean("HasWater", hasWater); tag.putBoolean("Boiled", boiled);
        tag.putInt("FuelTicks", fuelTicks); tag.putInt("HeatProgress", heatProgress); tag.putInt("TeaType", teaType);
    }
    @Override public void load(CompoundTag tag) {
        super.load(tag);
        hasWater = tag.getBoolean("HasWater"); boiled = tag.getBoolean("Boiled");
        fuelTicks = tag.getInt("FuelTicks"); heatProgress = tag.getInt("HeatProgress"); teaType = tag.getInt("TeaType");
    }
}
