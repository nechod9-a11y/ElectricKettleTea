package com.illia.electrickettle.registry;

import com.illia.electrickettle.ElectricKettleTea;
import com.illia.electrickettle.block.ElectricKettleBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ElectricKettleTea.MOD_ID);
    public static final RegistryObject<Block> ELECTRIC_KETTLE = BLOCKS.register("electric_kettle", () -> new ElectricKettleBlock(Block.Properties.of().mapColor(MapColor.METAL).strength(2.0F).sound(SoundType.METAL).noOcclusion()));
}
